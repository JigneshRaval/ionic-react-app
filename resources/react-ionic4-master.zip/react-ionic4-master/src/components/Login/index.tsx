import React from "react";
import {
  IonApp,
  IonContent,
  IonButton,
  IonIcon,
  IonGrid,
  IonRow,
  IonCol,
  IonImg
} from "@ionic/react";
import "./Login.scss";
import Google from "../../assets/search.svg";
import Logo from "../../assets/lunch-box.svg";

export default (props: any) => {
  const { push } = props.history;

  return (
    <IonContent class="login">
      <IonGrid>
        <IonRow>
          <IonCol>
            <div className="login__wrapper">
              <IonImg class="login__logo" src={Logo} />
              <IonButton
                class="login__button button login__button--google"
                expand="block"
                color="light"
                onClick={() => push('/home')}
              >
                <IonImg class="button__google" src={Google} />
                Google Login
              </IonButton>
            </div>
          </IonCol>
        </IonRow>
      </IonGrid>
    </IonContent>
  );
};
