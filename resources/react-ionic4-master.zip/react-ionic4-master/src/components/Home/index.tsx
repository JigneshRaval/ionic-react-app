import React, { Component } from 'react'
import { IonContent } from '@ionic/react';

export default class Home extends Component {
  render() {
    return (
      <IonContent>
        Home
      </IonContent>
    )
  }
}
